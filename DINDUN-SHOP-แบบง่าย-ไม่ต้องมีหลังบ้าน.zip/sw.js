/* network-first: ออนไลน์จะได้หน้าใหม่เสมอ ถ้าออฟไลน์ใช้ของที่เก็บไว้ */
var C="dd-v1";
self.addEventListener("install",function(e){self.skipWaiting()});
self.addEventListener("activate",function(e){e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k!==C}).map(function(k){return caches.delete(k)}))}).then(function(){return self.clients.claim()}))});
self.addEventListener("fetch",function(e){var r=e.request;if(r.method!=="GET"||new URL(r.url).origin!==location.origin)return;
 e.respondWith(fetch(r).then(function(res){if(res&&res.ok){var c=res.clone();caches.open(C).then(function(x){x.put(r,c)})}return res}).catch(function(){return caches.match(r).then(function(m){return m||caches.match("./")})}))});
